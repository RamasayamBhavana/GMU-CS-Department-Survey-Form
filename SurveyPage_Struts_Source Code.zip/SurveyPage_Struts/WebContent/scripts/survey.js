
	function savenameCookie(wrongPerson)
	{
		if(wrongPerson) {
			document.cookie = null;
		}
		var now=new Date();
		var hour=now.getHours();
		var name;
		if(hour<12)
		   document.write("<h5> Good Morning , ")
		else
		{
			hour=hour-12;
			if(hour<6)
			   document.write("<h5> Good Afternoon , ");
			else
			    document.write("<h5> Good Evening , ");	
		}
		if (document.cookie)
		{
		     var myCookie = unescape ( document.cookie );
		     var cookieTokens=myCookie.split("=");
		     name=cookieTokens[1];
		}
		if ((document.cookie && (name == "null" || !name))
			|| !document.cookie)
		{
		   name=window.prompt("Please enter your name","Bhavana");
		   document.cookie="name" + escape(name);
		}
		if(name)
		document.writeln(name + ", welcome to Assignment 3! </h5>");
		document.writeln("<a href='javascript:wrongPerson()'>Click here if you are not " + name +"</a>" );
	}
		
		function wrongPerson()
		{
			document.cookie="name=null;"+
				"expires=Thu, 01-Jan-95 00:00:01 GMT";
			
			//savenameCookie(true);
			location.reload();
		}
		
		function average1()
		{
			
			var num=document.getElementById("data1").value;
			var tokens= num.split(",");
			if(tokens.length >=10)
			{	
			document.getElementById("averageid").value=avg(tokens);
			document.getElementById("maximumid").value=max(tokens);
			}
			else 
				alert("Enter atleast 10 numbers");
		}
		function avg(tokens)
		{	
			var sum=0;
			for( var i=0; i<tokens.length; i++)
			{ 
				sum=sum+parseInt(tokens[i]);
			}
			return sum/tokens.length;
		}
		function max(tokens)
		{
			var temp=0;
			for( var j=0; j<tokens.length; j++)
			{	
				if(temp<parseInt(tokens[j]))
				{
					temp=tokens[j];
				}
			}
			return temp;
		}

		function validate()
		{	
			document.getElementById('error').innerHTML = "<h4>The following are the errors:</h4>";
			var isNameValid = checkname();
			var isAddrsValid = checkaddress();
            var isChkBxChked = checkbox();
			var isRadioChecked = checkradio();
			var isEmailValid = checkemail();

			if(isNameValid && isAddrsValid && isChkBxChked && isRadioChecked && isEmailValid) 
			{
				document.getElementById("f").submit();
			}
			else
			{
				window.scrollTo(0, 0);
			}
			
			return false;
		}
		function checkname()
		{	if(document.f.lastname.value=='')
				document.getElementById('error').innerHTML += "<br>LastName should not be empty";
			if(document.f.firstname.value=='')
				document.getElementById('error').innerHTML += "<br>FirstName should not be empty";
			var regex = /^[a-zA-Z]*$/;
                        if ((regex.test(document.f.lastname.value))&& (regex.test(document.f.firstname.value))&& (regex.test(document.f.middlename.value))) 
			{
				return true;
  			} else 
			{
		
				document.getElementById('error').innerHTML += "<br>Name should contain only alphabets";
				return false;
  			}
		}
		
		function checkaddress()
		{
			var regex1 = /^[a-zA-Z0-9!@#$%^&, ]*$/;
			if (regex1.test(document.f.streetaddress.value))
			{
				return true;
			} else
			{
				
				document.getElementById('error').innerHTML += "<br> Address should contain only alphanumeric characters"
				return false;
			}
		}

		function checkbox()
		{ 					
			var j=0;
			var check = document.getElementsByName("c1");
			for (var i = 0, len = check.length; i < len; i++) {
         			if (check[i].checked) {
              				j++;
				}
			}
			if(j<2)
			{
				
				document.getElementById('error').innerHTML += "<br> Atleast two checkboxes should be checked";
				return false;
			}
			return true;
		}
		

		function checkradio()
		{
			var isChecked = false;
			var radios = document.getElementsByName("check");
			for (var i = 0, len = radios.length; i < len; i++) {
				if (radios[i].checked) {
						isChecked = true;
				}
			}

			if(!isChecked) 
			{
				
				document.getElementById('error').innerHTML += "<br> Atleast one radio box should be checked"
			}
			
			return isChecked;
 		}

		function checkemail()
		{	
			var regex2=/^[a-zA-Z0-9]*@[a-zA-Z0-9]*\.[a-zA-Z]{2,3}$/;
			
			if (regex2.test(document.f.Email.value))
			{
				return true;
			}
			else
			{
				document.getElementById('error').innerHTML += "<br> Enter the email in the shown format";
				
				return false;
			}
		}

		function populateStateCity() {
	
			var zipCodeVal = document.getElementById("Zipcode").value;

			if (zipCodeVal.toString().length == 5) {
				
				try {
					var xmlHttpReq = new XMLHttpRequest();

					xmlHttpReq.onreadystatechange = function() {
						if (xmlHttpReq.readyState == 4 && xmlHttpReq.status == 200) {
							var jsonZipCodes = JSON.parse(xmlHttpReq.responseText);

							for (var numZip = 0; numZip < 4; numZip++) {
								var zipCodesVal = jsonZipCodes.zipcodes[numZip];
								if (zipCodeVal == zipCodesVal.zip) {
									document.getElementById("City").innerHTML = zipCodesVal.city;
									document.getElementById("State").innerHTML = zipCodesVal.state;

									return true;
								} else {
									document.getElementById("City").innerHTML = "";
									document.getElementById("State").innerHTML = "";
								}
							}
							
						}
					}

					xmlHttpReq.open("GET", "zipCodes.json", true);
					xmlHttpReq.send();
				} catch (exception) {
					return false;
				}
			} else if(zipCodeVal.toString().length == 0) {
				//document.getElementById("zipError").style.display = "none";
			}
		}