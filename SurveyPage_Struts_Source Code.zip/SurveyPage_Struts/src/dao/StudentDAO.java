package dao;

	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.util.ArrayList;

	import org.apache.commons.lang3.StringUtils;

	import bean.StudentBean;

/**
 * This class is used to store the student form data to the database table
 * 
 * @author Bhavana Ramasayam
 *
 */
	public class StudentDAO {
		final private String DRIVER_NAME = "oracle.jdbc.driver.OracleDriver";
		final private String DATABASE_URL = "jdbc:oracle:thin:@apollo.ite.gmu.edu:1521:ite10g";
		final private String USER_NAME = "bramasay";
		final private String PASSWORD = "compoo";

		public Connection getConnection() throws Exception {
			Class.forName(DRIVER_NAME);
			Connection conn = DriverManager.getConnection(DATABASE_URL, USER_NAME,
					PASSWORD);
			return conn;
		}

		public boolean saveStudentSurveyInfo(StudentBean studentBean) {
			boolean isUniqueConstraintViolated = false;

			PreparedStatement preparedStatement = null;
			Connection sqlConnection = null;
			try {
				sqlConnection = getConnection();

				preparedStatement = sqlConnection
						.prepareStatement("insert into Student (studentid, lastname, firstname, middlename, streetaddress, zipcode, city, state, telnum, email, gradmonth, gradyear, "
								+ "url, surveydate, likings, interest ,recommend) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

				preparedStatement.setString(1, studentBean.getStudentId());
				preparedStatement.setString(2, studentBean.getLastName());
				preparedStatement.setString(3, studentBean.getFirstName());
				preparedStatement.setString(4, studentBean.getMiddleName());
				preparedStatement.setString(5, studentBean.getStreetAddr());
				preparedStatement.setString(6, studentBean.getZipCode());
				preparedStatement.setString(7, studentBean.getCityDiv());
				preparedStatement.setString(8, studentBean.getStateDiv());
				preparedStatement.setString(9, studentBean.getTelNum());
				preparedStatement.setString(10, studentBean.getEmailAddr());
				preparedStatement.setString(11, studentBean.getGradMonth());

				if (StringUtils.isEmpty(studentBean.getGradYear())) {
					studentBean.setGradYear("0");
				}
				preparedStatement.setInt(12,
						Integer.parseInt(studentBean.getGradYear()));
				preparedStatement.setString(13, studentBean.getUrl());
				preparedStatement.setString(14, studentBean.getDateOfSurvey());
				preparedStatement.setString(15, studentBean.getLikings());
				preparedStatement.setString(16, studentBean.getInterest());
				preparedStatement.setString(17, studentBean.getRecommendation());

				preparedStatement.executeUpdate();

			} catch (Exception e) {
				e.printStackTrace();

				if (StringUtils.contains(e.getMessage(), "unique constraint")) {
					isUniqueConstraintViolated = true;
				}
			} finally {
				try {
					preparedStatement.close();
					sqlConnection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			return isUniqueConstraintViolated;
		}

		public ArrayList<String> retrieveStudentIds() {
			ArrayList<String> studentIds = null;

			ResultSet resultSet = null;
			PreparedStatement preparedStatement = null;
			Connection sqlConnection = null;
			try {
				studentIds = new ArrayList<String>();
				sqlConnection = getConnection();

				String query = "SELECT studentid FROM Student";
				preparedStatement = sqlConnection.prepareStatement(query);

				resultSet = preparedStatement.executeQuery();
				while (resultSet.next()) {
					studentIds.add(resultSet.getString("studentid"));
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					resultSet.close();
					preparedStatement.close();
					sqlConnection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			return studentIds;
		}

		public StudentBean retrieveStudentSurveyInfo(String studentId) {
			StudentBean studentBean = null;

			ResultSet resultSet = null;
			PreparedStatement preparedStatement = null;
			Connection sqlConnection = null;
			try {
				studentBean = new StudentBean();
				sqlConnection = getConnection();

				String query = "SELECT * FROM Student WHERE studentid = '"
						+ studentId + "'";
				preparedStatement = sqlConnection.prepareStatement(query);

				resultSet = preparedStatement.executeQuery();
				while (resultSet.next()) {
					studentBean.setStudentId(studentId);
					studentBean.setLastName(resultSet.getString(2));
					studentBean.setFirstName(resultSet.getString(3));
					studentBean.setMiddleName(resultSet.getString(4));
					studentBean.setStreetAddr(resultSet.getString(5));
					studentBean.setZipCode(resultSet.getString(6));
					studentBean.setCityDiv(resultSet.getString(7));
					studentBean.setStateDiv(resultSet.getString(8));
					studentBean.setTelNum(resultSet.getString(9));
					studentBean.setEmailAddr(resultSet.getString(10));
					studentBean.setGradMonth(resultSet.getString(11));
					studentBean.setGradYear(resultSet.getString(12));
					studentBean.setUrl(resultSet.getString(13));
					studentBean.setDateOfSurvey(resultSet.getString(14));
					studentBean.setRecommendation(resultSet.getString(15));
					studentBean.setInterest(resultSet.getString(16));
					studentBean.setLikings(resultSet.getString(17));
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					resultSet.close();
					preparedStatement.close();
					sqlConnection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			return studentBean;
		}
	}

