package bean;

import java.util.ArrayList;

/**
 * This class is a POJO class in which all the student details bean are present.
 * 
 * @author Bhavana Ramasayam
 */

public class StudentBean {
	public String studentId;
	public String lastName;
	public String firstName;
	public String middleName;
	public String streetAddr;
	public String zipCode;
	public String cityDiv;
	public String stateDiv;
	public String telNum;
	public String emailAddr;
	public String gradMonth;
	public String gradYear;
	public String url;
	public String dateOfSurvey;
	public String recommendation;
	public String interest;
	public String likings;
	private ArrayList<String> studentIds;

	/**
	 * @return the studentId
	 */
	public String getStudentId() {
		return studentId;
	}

	/**
	 * @param studentId
	 *            the studentId to set
	 */
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	/**
	 * @return the streetAddr
	 */
	public String getStreetAddr() {
		return streetAddr;
	}

	/**
	 * @param streetAddr
	 *            the streetAddr to set
	 */
	public void setStreetAddr(String streetAddr) {
		this.streetAddr = streetAddr;
	}

	/**
	 * @return the zipCode
	 */
	public String getZipCode() {
		return zipCode;
	}

	/**
	 * @param zipCode
	 *            the zipCode to set
	 */
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	/**
	 * @return the cityDiv
	 */
	public String getCityDiv() {
		return cityDiv;
	}

	/**
	 * @param cityDiv
	 *            the cityDiv to set
	 */
	public void setCityDiv(String cityDiv) {
		this.cityDiv = cityDiv;
	}

	/**
	 * @return the stateDiv
	 */
	public String getStateDiv() {
		return stateDiv;
	}

	/**
	 * @param stateDiv
	 *            the stateDiv to set
	 */
	public void setStateDiv(String stateDiv) {
		this.stateDiv = stateDiv;
	}

	/**
	 * @return the telNum
	 */
	public String getTelNum() {
		return telNum;
	}

	/**
	 * @param telNum
	 *            the telNum to set
	 */
	public void setTelNum(String telNum) {
		this.telNum = telNum;
	}

	/**
	 * @return the emailAddr
	 */
	public String getEmailAddr() {
		return emailAddr;
	}

	/**
	 * @param emailAddr
	 *            the emailAddr to set
	 */
	public void setEmailAddr(String emailAddr) {
		this.emailAddr = emailAddr;
	}

	/**
	 * @return the gradMonth
	 */
	public String getGradMonth() {
		return gradMonth;
	}

	/**
	 * @param gradMonth
	 *            the gradMonth to set
	 */
	public void setGradMonth(String gradMonth) {
		this.gradMonth = gradMonth;
	}

	/**
	 * @return the gradYear
	 */
	public String getGradYear() {
		return gradYear;
	}

	/**
	 * @param gradYear
	 *            the gradYear to set
	 */
	public void setGradYear(String gradYear) {
		this.gradYear = gradYear;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url
	 *            the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * @return the dateOfSurvey
	 */
	public String getDateOfSurvey() {
		return dateOfSurvey;
	}

	/**
	 * @param dateOfSurvey
	 *            the dateOfSurvey to set
	 */
	public void setDateOfSurvey(String dateOfSurvey) {
		this.dateOfSurvey = dateOfSurvey;
	}

	/**
	 * @return the recommendation
	 */
	public String getRecommendation() {
		return recommendation;
	}

	/**
	 * @param recommendation
	 *            the recommendation to set
	 */
	public void setRecommendation(String recommendation) {
		this.recommendation = recommendation;
	}

	/**
	 * @return the interest
	 */
	public String getInterest() {
		return interest;
	}

	/**
	 * @param interest
	 *            the interest to set
	 */
	public void setInterest(String interest) {
		this.interest = interest;
	}

	/**
	 * @return the likings
	 */
	public String getLikings() {
		return likings;
	}

	/**
	 * @param likings
	 *            the likings to set
	 */
	public void setLikings(String likings) {
		this.likings = likings;
	}
	/**
	 * @return the studentIds
	 */
	public ArrayList<String> getStudentIds() {
		return studentIds;
	}

	/**
	 * @param studentIds
	 *            the studentIds to set
	 */
	public void setStudentIds(ArrayList<String> studentIds) {
		this.studentIds = studentIds;
	}
}
