package bean;

/**
 * This is a POJO or a bean class in which all the data is been stored.
 * 
 * @author Bhavana Ramasayam
 */

public class DataBean {
	private String dataNumbers;

	private double meanValue;

	private double standardDeviationVal;

	/**
	 * @return the dataNumbers
	 */
	public String getDataNumbers() {
		return dataNumbers;
	}

	/**
	 * @param dataNumbers
	 *            the dataNumbers to set
	 */
	public void setDataNumbers(String dataNumbers) {
		this.dataNumbers = dataNumbers;
	}

	/**
	 * @return the meanValue
	 */
	public double getMeanValue() {
		return meanValue;
	}

	/**
	 * @param meanValue
	 *            the meanValue to set
	 */
	public void setMeanValue(double meanValue) {
		this.meanValue = meanValue;
	}

	/**
	 * @return the standardDeviationVal
	 */
	public double getStandardDeviationVal() {
		return standardDeviationVal;
	}

	/**
	 * @param standardDeviationVal
	 *            the standardDeviationVal to set
	 */
	public void setStandardDeviationVal(double standardDeviationVal) {
		this.standardDeviationVal = standardDeviationVal;
	}
}